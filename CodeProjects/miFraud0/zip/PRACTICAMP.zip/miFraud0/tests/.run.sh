touch tests//.timeout
CMD=" /home/ulises/Documents/MP/UGRMPBase/CodeProjects/miFraud0/build/miFraud0  < ../Datasets/dataP0/princeton_0locations.p0in 1> tests//.out7 2>&1"
eval $CMD
rm tests//.timeout
