touch tests//.timeout
CMD=" /home/ulises/Documents/MP/github/UGRMPBase-ulises/CodeProjects/miFraud1/build/Fraud1  < ../Datasets/dataP1/princeton.p1in 1> tests//.out8 2>&1"
eval $CMD
rm tests//.timeout
